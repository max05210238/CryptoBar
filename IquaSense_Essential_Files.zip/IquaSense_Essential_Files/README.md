# IquaSense Essential Files

This package contains the minimal files needed for IquaSense development.

## Contents

1. **lib/EPD_2in9g/** - Complete WaveShare 2.9" 4-color e-paper display driver
   - Hardware abstraction (DEV_Config.h/cpp)
   - Display driver (EPD_2in9g.h/cpp)
   - Paint library (GUI_Paint.h/cpp)
   - Fonts (8pt, 12pt, 16pt, 20pt, 24pt)

2. **HARDWARE_PLATFORM_DOCUMENTATION.md** - Complete technical reference
   - Hardware specifications
   - Pin mapping
   - Driver usage guide
   - Code examples
   - Troubleshooting

## Quick Start

1. Create new PlatformIO project:
   ```bash
   mkdir IquaSense
   cd IquaSense
   platformio init --board esp32-s3-devkitc-1
   ```

2. Copy the driver library:
   ```bash
   cp -r /path/to/IquaSense_Essential_Files/lib/EPD_2in9g lib/
   ```

3. Read the documentation:
   ```
   HARDWARE_PLATFORM_DOCUMENTATION.md
   ```

4. Start coding!

## Pin Mapping (ESP32-S3)

| Function | GPIO Pin |
|----------|----------|
| E-Paper SCK  | GPIO 12 |
| E-Paper MOSI | GPIO 11 |
| E-Paper CS   | GPIO 10 |
| E-Paper DC   | GPIO 17 |
| E-Paper RST  | GPIO 16 |
| E-Paper BUSY | GPIO 4  |
| LED External | GPIO 48 |
| Encoder CLK  | GPIO 2  |
| Encoder DT   | GPIO 1  |
| Encoder SW   | GPIO 3  |

## Critical Initialization

```cpp
#include "lib/EPD_2in9g/DEV_Config.h"
#include "lib/EPD_2in9g/EPD_2in9g.h"
#include "lib/EPD_2in9g/GUI_Paint.h"

UBYTE *imageBuffer;

void setup() {
    // Initialize hardware
    DEV_Module_Init();
    EPD_2IN9G_Init();

    // Allocate buffer
    UWORD imagesize = ((EPD_2IN9G_WIDTH % 4 == 0) ?
                       (EPD_2IN9G_WIDTH / 4) :
                       (EPD_2IN9G_WIDTH / 4 + 1)) * EPD_2IN9G_HEIGHT;
    imageBuffer = (UBYTE *)malloc(imagesize);

    // Initialize Paint library - CRITICAL!
    Paint_NewImage(imageBuffer, EPD_2IN9G_WIDTH, EPD_2IN9G_HEIGHT,
                   90, EPD_2IN9G_WHITE);
    Paint_SetScale(4);  // Must set scale=4 for 4-color mode!
    Paint_SelectImage(imageBuffer);
    Paint_Clear(EPD_2IN9G_WHITE);

    // Clear display
    EPD_2IN9G_Clear(EPD_2IN9G_WHITE);
}
```

## Source

Extracted from CryptoBar project:
https://github.com/max05210238/CryptoBar
Branch: claude/4color-display-V099r-G-K0kQP
Date: 2026-01-11

## License

WaveShare driver library: MIT License (original from WaveShare)
Documentation: Created for IquaSense project
