// Minimal Example for IquaSense
// This example shows basic display initialization and text rendering

#include <Arduino.h>
#include "lib/EPD_2in9g/DEV_Config.h"
#include "lib/EPD_2in9g/EPD_2in9g.h"
#include "lib/EPD_2in9g/GUI_Paint.h"

UBYTE *imageBuffer = NULL;

void initDisplay() {
    Serial.begin(115200);
    Serial.println("Initializing display...");

    // Hardware init
    DEV_Module_Init();
    EPD_2IN9G_Init();

    // Allocate image buffer (9,472 bytes)
    UWORD imagesize = ((EPD_2IN9G_WIDTH % 4 == 0) ?
                       (EPD_2IN9G_WIDTH / 4) :
                       (EPD_2IN9G_WIDTH / 4 + 1)) * EPD_2IN9G_HEIGHT;
    imageBuffer = (UBYTE *)malloc(imagesize);

    if (!imageBuffer) {
        Serial.println("ERROR: Failed to allocate buffer!");
        while(1);
    }

    // Initialize Paint library with PHYSICAL dimensions
    Paint_NewImage(imageBuffer, EPD_2IN9G_WIDTH, EPD_2IN9G_HEIGHT,
                   90, EPD_2IN9G_WHITE);

    // CRITICAL: Set scale to 4 for 4-color mode
    Paint_SetScale(4);

    Paint_SelectImage(imageBuffer);
    Paint_Clear(EPD_2IN9G_WHITE);

    // Clear physical display
    Serial.println("Clearing display (takes ~20 seconds)...");
    EPD_2IN9G_Clear(EPD_2IN9G_WHITE);

    Serial.println("Display ready!");
}

void displayWaterQuality(int tds, float ph, float temp) {
    // Clear buffer
    Paint_Clear(EPD_2IN9G_WHITE);

    // Title
    Paint_DrawString_EN(10, 10, "IquaSense Monitor", &Font20,
                        EPD_2IN9G_BLACK, EPD_2IN9G_WHITE);

    // Draw separator line
    Paint_DrawLine(5, 35, 291, 35, EPD_2IN9G_BLACK,
                   DOT_PIXEL_1X1, LINE_STYLE_SOLID);

    // TDS
    char tdsStr[32];
    sprintf(tdsStr, "TDS: %d ppm", tds);
    UWORD tdsColor = (tds > 300) ? EPD_2IN9G_YELLOW : EPD_2IN9G_BLACK;
    Paint_DrawString_EN(10, 45, tdsStr, &Font16, tdsColor, EPD_2IN9G_WHITE);

    // pH
    char phStr[32];
    sprintf(phStr, "pH: %.1f", ph);
    Paint_DrawString_EN(10, 70, phStr, &Font16,
                        EPD_2IN9G_BLACK, EPD_2IN9G_WHITE);

    // Temperature
    char tempStr[32];
    sprintf(tempStr, "Temp: %.1f C", temp);
    Paint_DrawString_EN(10, 95, tempStr, &Font16,
                        EPD_2IN9G_BLACK, EPD_2IN9G_WHITE);

    // Update display (takes 15-20 seconds)
    Serial.println("Updating display...");
    EPD_2IN9G_Display(imageBuffer);
    Serial.println("Display updated!");
}

void setup() {
    initDisplay();

    // Example: Display some test data
    displayWaterQuality(250, 7.2, 23.5);
}

void loop() {
    // Update every 5 minutes
    delay(5 * 60 * 1000);

    // Get real sensor data here
    int tds = 250;     // Replace with actual sensor
    float ph = 7.2;    // Replace with actual sensor
    float temp = 23.5; // Replace with actual sensor

    displayWaterQuality(tds, ph, temp);
}
